package tinhSoNamGuiTien;

import java.util.Scanner;

public class xuLy {

	public xuLy() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		double tienGui;
		double soTienMongMuon;
		float ls;
		int nam;
		Scanner nhap = new Scanner(System.in);
		do {
			System.out.println("Vui lòng nhập số tiền gửi (tr) vào");
			tienGui = Long.parseLong(nhap.nextLine());
			System.out.println("Vui lòng nhập số tiền mong muốn (tr) vào");
			soTienMongMuon = Long.parseLong(nhap.nextLine());
			System.out.println("Vui lòng lãi suất vào");
			ls = Integer.parseInt(nhap.nextLine());
		} while (tienGui <= 0 || soTienMongMuon <= 0 || ls <= 0);
		// laikep = tiengui*(1+ls)^nam
		float r =ls/100;
		nam = (int) Math.ceil(Math.log(soTienMongMuon/tienGui) / Math.log(1+r));
		System.out.print("Tổng số kỳ hạn là: "+nam+" năm");
	}
}
