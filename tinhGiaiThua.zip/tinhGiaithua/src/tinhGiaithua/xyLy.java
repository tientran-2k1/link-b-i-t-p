package tinhGiaithua;

import java.util.Scanner;

public class xyLy {

	public xyLy() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		int n;
		long giaiThua = 1;
		Scanner nhap = new Scanner(System.in);
		do {
			System.out.println("Vui lòng nhập số n vào: ");
			n = nhap.nextInt();
		} while (n <= 0);
		if (n == 0 || n == 1) {
			System.out.println("Giai thừa "+ n +"! là: "+ giaiThua);
		}
		else {
			for (int i = 1; i <= n; i++) {
				giaiThua *= i;
		}
			System.out.println("Giai thừa "+ n +"! là: "+ giaiThua);
		}
	}

}
